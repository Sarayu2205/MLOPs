CLA 4 — ML Model Deployment Strategies and Model Serving using FastAPI

Files in this ZIP:
1. CLA4_Complete.ipynb — Google Colab notebook for all assignment tasks.
2. train-selected-columns.csv — labelled Titanic dataset provided for the assignment.

How to run:
1. Extract this ZIP on your computer.
2. Open https://colab.research.google.com/
3. Choose File > Upload notebook and upload CLA4_Complete.ipynb.
4. Run the notebook cells from top to bottom.
5. When the dataset upload prompt appears, upload train-selected-columns.csv.
   The notebook accepts this filename and saves it internally as train.csv.
6. Continue running all cells. The notebook should generate the model, predictions,
   FastAPI files, observations report, and related outputs after execution.

Important:
- This ZIP contains the notebook and dataset, not generated execution results.
- Run the notebook in Colab to create model.pkl, batch_predictions.csv, reports, and other outputs.
